#04 Te Amo<3


tupla = {"helen": 5 , "vini":10 ,"tamires":8}

for v in tupla.keys():
    if tupla[v] > 7:
        print(v)
        