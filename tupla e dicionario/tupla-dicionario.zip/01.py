#te amo = <3

fruta = ("abacaxi","uva","morango","manga","kiwi")

print(f"a primeira fruta é {fruta[0]}")
print(f"a ultima fruta é {fruta[4]}")