#02

dici = {"nome":"viniciús","idade":"16","cidade":"criciuma"}

print(f"1°{dici['nome']}\n2°{dici['idade']}\n3°{dici['cidade']}")