#05

pessoas = {"nome":"sla", "idade" :12 ,"endereços":("criciuma","lauro-miler")}

print(pessoas["endereços"][1])
    
