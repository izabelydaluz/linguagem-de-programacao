

biblioteca ={
    "diario de um banana":("Jeff Kinney", 2007),
    "massacre da família Hope":("Riley Sager", 1929),
    "a metamorfose":("Franz Kafka", 1915),
}


print('''
    "diario de um banana":("Jeff Kinney", 2007),
    "massacre da família Hope":("Riley Sager", 1929),
    "a metamorfose":("Franz Kafka", 1915)''')

print("informe qual deseja pesquisar:")
op3 = input("respota: ").lower()

print(biblioteca[op3])


